package com.yt1.twittersearchactivity;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import com.yt1.twittersearchactivity.R;
/*
import com.google.firebase.appindexing.Action;
import com.google.firebase.appindexing.FirebaseUserActions;
import com.google.firebase.appindexing.Indexable;
import com.google.firebase.appindexing.builders.Actions;
*/

public class MainActivity extends AppCompatActivity {

    private TextView tweetDisplay;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
   private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tweetDisplay = (TextView) findViewById(R.id.tweet_txt);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
       client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void searchTwitter(View view) {
        EditText searchTxt = (EditText) findViewById(R.id.search_edit);
        String searchTerm = searchTxt.getText().toString();
        if (searchTerm.length() > 0) {
            try {
                String encodedSearch = URLEncoder.encode(searchTerm, "UTF-8");
                String searchURL = "https://api.twitter.com/1.1/search/tweets.json?q=%23" + encodedSearch;
                new GetTweets().execute(searchURL);

            } catch (Exception e) {
                tweetDisplay.setText("Whoops - something went wrong!");
                e.printStackTrace();
            }

        } else
            tweetDisplay.setText("Enter a search query!");

    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Main Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }

    private class GetTweets extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... twitterURL) {
            StringBuilder tweetFeedBuilder = new StringBuilder();
            for (String searchURL : twitterURL) {
                HttpClient tweetClient = new DefaultHttpClient();
                try {
                    HttpGet tweetGet = new HttpGet(searchURL);
                    HttpResponse tweetResponse = tweetClient.execute(tweetGet);
                    StatusLine searchStatus = tweetResponse.getStatusLine();
                    if (searchStatus.getStatusCode() == 200) {
                        HttpEntity tweetEntity = tweetResponse.getEntity();
                        InputStream tweetContent = tweetEntity.getContent();
                        InputStreamReader tweetInput = new InputStreamReader(tweetContent);
                        BufferedReader tweetReader = new BufferedReader(tweetInput);
                        String lineIn;
                        while ((lineIn = tweetReader.readLine()) != null) {
                            tweetFeedBuilder.append(lineIn);
                        }

                    } else
                        Log.d("Tweet", "fail");
                    //tweetDisplay.setText("Whoops - something went wrong!");
                } catch (Exception e) {
                    //tweetDisplay.setText("Whoops - something went wrong!");
                    e.printStackTrace();
                }
            }
                return tweetFeedBuilder.toString();
        }

        protected void onPostExecute(String result) {
            StringBuilder tweetResultBuilder = new StringBuilder();
            try {
                JSONObject resultObject = new JSONObject(result);
                JSONArray tweetArray = resultObject.getJSONArray("results");
                for (int t = 0; t < tweetArray.length(); t++) {
                    JSONObject tweetObject = tweetArray.getJSONObject(t);
                    tweetResultBuilder.append(tweetObject.getString("from_user") + ": ");
                    tweetResultBuilder.append(tweetObject.get("text") + "\n\n");


                }

            } catch (Exception e) {
                tweetDisplay.setText("Whoops - something went wrong!");
                e.printStackTrace();
            }
            if (tweetResultBuilder.length() > 0)
                tweetDisplay.setText(tweetResultBuilder.toString());
            else
                tweetDisplay.setText("Sorry - no tweets found for your search!");


        }

    }
}
